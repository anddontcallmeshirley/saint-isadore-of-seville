# main.py 
# 
# written by Paul Lamping
# 
# This program is part of a solution to the Array Diff Pre-Interview Programming Questions
# It solves the task that was asked to write a function that takes 2 arrays of integers and produces 2 arrays representing the additions and deletions.

# to test, simply populate the current and target lists with your desired testing parameters and execute in a python interpreter.


def getAddDel(current, target):
    additions = list(set(target) - set(current))
    deletions = list(set(current) - set(target))
    return (additions, deletions)

current = [1,3,5,6,8,9]
target = [1,2,5,7,9]

(additions, deletions) = getAddDel(current, target)
print "additions:" , additions
print "deletions:" , deletions
