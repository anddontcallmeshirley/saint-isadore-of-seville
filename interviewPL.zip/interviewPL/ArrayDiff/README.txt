README.txt file for ArrayDiff program.

To run, execute main.py in a Python interpreter.

The task was to write a function or program in Python, Java or Scala that takes 2 arrays of integers, "current" and "target" and produces 2 arrays representing an additions list and a deletions list.

The solution presented in the main.py is a function written in Python.

The function is getAddDel and can be called like this,
(additions, deletions) = getAddDel(current, target)


