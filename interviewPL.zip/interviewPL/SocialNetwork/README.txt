README.txt file for Social Network Analysis program.

To run, execute main.py in a Python interpreter.

The task was to write a program in Python, Java or Scala that analyzes this social network to output the number of viewers any piece of original content has reached.

The solution presented in the main.py is a program written in Python.

The data file is 'data.csv' and must be present in the same directory as main.py for the program to work.

For testing, simply modify the values of data.csv and run the program and see that the output is adjusted accordingly.
