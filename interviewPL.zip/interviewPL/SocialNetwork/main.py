# main.py 
# 
# written by Paul Lamping
# 
# This program is part of a solution to the Social Network Analysis Pre-Interview Programming Questions.
# It solves the task that was asked to write a program that determines the total number of followers an original post has, including subposts.

# The task mentions nothing about checking validity of data, so we will assume the data in the data.csv file is valid, and ordered correctly (the process flow may not work otherwise, but it was not in the requirements).

# to test, simply populate the data.csv data file with your desired testing parameters and execute in a python interpreter.

# program in Python
    
import csv
ReadData=csv.reader(open('data.csv','r'), delimiter=',')

dataArray = list(ReadData)

# make copy, for iterating a second time.
dataArray2 = dataArray

#print dataArray - would look like this
# [['postId', 'repostId', 'followers'], ['1', '-1', '120'], ['2', '1', '60'], ['3', '1', '30'], ['4', '2', '90'], ['5', '3', '40'], ['6', '4', '10'], ['7', '-1', '240'], ['8', '7', '190'], ['9', '7', '50']] 

# sample data
# line[0] = 1 (postId)
# line[1] = -1 (repostId)
# line[2] = 120 (followers)

# keep track of totals in a new list.
total2=list()
for line in dataArray:
    if line[1] == 'repostId':
        # this is a header line. Do nothing.
        #print "header line"
        xyz=1
    elif line[1] == '-1':
        # and original post, not a repost.
        #print "original " , line[0], line[2]
        # in total2, add value to number of followers.
        total2+=[[line[0],line[2]]]
    elif line[1] > 0:
        # not an original post but a repost. Add up followers.
        # search for original post, then add value to number of followers.

        # set a flag if value was an original.
        original = False
        # search through total2, add value to number of followers.
        for t in total2:
            # total2 looks like [['1', 210], ['7', 480]] 
            # t looks like [['1', 210]
            if t[0] == line[1]:
                t[1] = int(t[1]) + int(line[2])
                original = True
        
        # if post was not an original, then set the repostId to the original postId.
        if original == False:
            # print line[0], " not original"
            # replace dataArray line[1] with line[1] of index at line[1]
            for l2 in dataArray2:
                #print "l2[0] ", l2[0]
                if l2[0] == line[1]:
                    # print "changing value of line[1] " , line[1], " to " , int(l2[1])
                    line[1] = int(l2[1])
                    # now that original postId has changed, try adding to totals again.
                    # search through total2, add value to number of followers.
                    for t in total2:
                        if int(t[0]) == int(line[1]):
                            t[1] = int(t[1]) + int(line[2])
            
#print total2

# print results
# results will be this:
# 1 :  350                                                                                                                                                     
# 7 :  480 

for x in total2:
    print x[0], ": " , x[1]
